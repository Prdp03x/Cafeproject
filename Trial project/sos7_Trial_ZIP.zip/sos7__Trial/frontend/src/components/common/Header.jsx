// import { useNavigate } from "react-router";
// import { FiShoppingCart } from "react-icons/fi";

// const Header = ({
//   brand,
//   cartCount = 0,
//   onCartClick,
//   loading = false,
// }) => {

//   const navigate = useNavigate();

//   // SKELETON UI
//   if (loading || !brand) {
//     return (
//       <div className="w-full py-4 flex items-center justify-between animate-pulse">

//         {/* LEFT */}
//         <div className="flex items-center gap-3">

//           <div className="h-10 w-10 rounded-full bg-gray-200" />

//           <div className="space-y-2">
//             <div className="h-4 w-28 bg-gray-200 rounded" />
//             <div className="h-3 w-20 bg-gray-200 rounded" />
//           </div>

//         </div>

//         {/* RIGHT */}
//         <div className="h-10 w-10 rounded-full bg-gray-200" />

//       </div>
//     );
//   }

//   return (
//     <div className="w-full py-4 flex items-center justify-between bg-gray-50">

//       {/* LEFT */}
//       <div
//         className="flex items-center gap-3 cursor-pointer"
//         onClick={() => navigate("/")}
//       >

//         {brand?.logo ? (
//           <img
//             src={brand.logo}
//             alt="logo"
//             className="h-10 w-10 object-cover rounded-full border"
//           />
//         ) : (
//           <div className="theme-primary flex h-10 w-10 items-center justify-center rounded-full text-white font-semibold">
//             {brand?.name?.charAt(0) || "C"}
//           </div>
//         )}

//         <div className="flex flex-col leading-tight">

//           <h1 className="text-black font-semibold text-base">
//             {brand?.name || "My Cafe"}
//           </h1>

//           <span className="text-xs text-gray-500">
//             Fresh & Tasty
//           </span>

//         </div>

//       </div>

//       {/* RIGHT */}
//       <div
//         onClick={onCartClick}
//         className="relative cursor-pointer"
//       >

//         <div className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-200 border border-gray-300 hover:bg-gray-300 transition">

//           <FiShoppingCart
//             className="text-gray-700"
//             size={18}
//           />

//         </div>

//         {cartCount > 0 && (
//           <span className="theme-primary absolute -top-1 -right-1 rounded-full px-1.5 py-0.5 text-[10px] text-white">
//             {cartCount}
//           </span>
//         )}

//       </div>

//     </div>
//   );
// };

// export default Header;

import { useNavigate } from "react-router";
import { FiShoppingCart, FiGrid, FiMapPin } from "react-icons/fi";

const Header = ({ 
  brand, 
  cartCount = 0, 
  onCartClick, 
  onTableClick,
  tableNumber,
  loading = false 
}) => {
  const navigate = useNavigate();

  if (loading || !brand) {
    return (
      <div className="w-full py-3 flex items-center justify-between animate-pulse">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-full bg-gray-200" />
          <div className="space-y-2">
            <div className="h-4 w-32 bg-gray-200 rounded-md" />
            <div className="h-3 w-20 bg-gray-200 rounded-md" />
          </div>
        </div>
        <div className="flex items-center gap-3">
           <div className="h-10 w-24 rounded-full bg-gray-200" />
           <div className="h-11 w-11 rounded-full bg-gray-200" />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full py-3 flex items-center justify-between">
      {/* Left: Brand */}
      <div
        className="flex items-center gap-3 cursor-pointer group"
        onClick={() => navigate("/")}
      >
        {brand?.logo ? (
          <img
            src={brand.logo}
            alt="logo"
            className="h-11 w-11 object-cover rounded-full border-2 border-white shadow-sm"
          />
        ) : (
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#14532d] text-white font-bold text-lg shadow-sm">
            {brand?.name?.charAt(0) || "C"}
          </div>
        )}

        <div className="flex flex-col leading-tight">
          <h1 className="text-gray-900 font-bold text-base tracking-tight group-hover:text-[#14532d] transition-colors">
            {brand?.name || "My Cafe"}
          </h1>
          <span className="text-[11px] font-medium text-gray-500 uppercase tracking-wider">
            Fresh & Tasty
          </span>
        </div>
      </div>

      {/* Right: Table & Cart */}
      <div className="flex items-center gap-2 sm:gap-3">
        
        {/* Table Indicator / Selector Button */}
        <button
          onClick={onTableClick}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-full text-xs sm:text-sm font-medium shadow-sm transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#14532d]/30 active:scale-95 ${
            tableNumber
              ? "bg-[#14532d] text-white hover:bg-[#0f3d22]"
              : "bg-white border border-gray-200 text-gray-700 hover:bg-gray-50"
          }`}
        >
          {tableNumber ? (
            <>
              <FiMapPin size={14} className="shrink-0" />
              <span>Table {tableNumber}</span>
            </>
          ) : (
            <>
              <FiGrid size={14} className="shrink-0" />
              <span className="hidden sm:inline">Select Table</span>
              <span className="sm:hidden">Table</span>
            </>
          )}
        </button>

        {/* Cart Button */}
        <button
          onClick={onCartClick}
          className="relative h-11 w-11 flex items-center justify-center rounded-full bg-gray-50 border border-gray-300 hover:bg-gray-100 hover:border-gray-300 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[#14532d]/20"
          aria-label="Open cart"
        >
          <FiShoppingCart className="text-gray-700" size={20} />

          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-5 min-w-[20px] items-center justify-center rounded-full bg-[#14532d] px-1.5 text-[11px] font-bold text-white shadow-sm ring-2 ring-white">
              {cartCount > 99 ? "99+" : cartCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default Header;